using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Data;
using System.Data.SqlClient;
using Amazon.Lambda.Core;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.SystemTextJson.DefaultLambdaJsonSerializer))]

namespace PushAPIToSQL
{
    public class Function
    {  
        /// <summary>
        /// A simple function that takes a string and does a ToUpper
        /// </summary>
        /// <param name="input"></param>
        /// <param name="context"></param>
        /// <returns></returns>

        public string FunctionHandler(string input, ILambdaContext context)
        {
            SqlDataReader sqlData = null;

            string sqladdress = "Data Source=stat-controler.cluster-cdzwulcek08o.eu-west-2.rds.amazonaws.com;Initial Catalog=StatControlSql;User ID=admin;Password=HowManyDucks2";
            SqlConnection connection = new SqlConnection(sqladdress);
            connection.Open();
            SqlCommand command = new SqlCommand("GetSteamIDs", connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Connection.Open();
            sqlData = command.ExecuteReader();
            List<long> steamIDDir = new List<long>();
            long id1 = 76561198035170263;
                /*
                 * 
                 * 
                 * Add SQL Pull User ID
                 * Then Add To steamIDDir
                 * 
                 */
                steamIDDir.Add(id1);
            List<string[,]> WeaponsForUser = new List<string[,]>();
            string errorlist = "";
            string steamAPIKey = "8858FC26F97BACC3D4BB4C44CA52969F";
            long steamID = 76561198035170263;
            string connectionURL = $"https://api.steampowered.com/ISteamUserStats/GetUserStatsForGame/v0002/?appid=730&key={ steamAPIKey }&steamid=";
            string[] responcearr;
            for (int z = 0; z < steamIDDir.Count; z++)
            {
                using (var client = new WebClient())
                {
                    string responce = client.DownloadString(connectionURL + steamIDDir[z].ToString());
                    if (!string.IsNullOrEmpty(responce))
                    {
                        string[,] weapons = new string[,] { { steamID.ToString(), "", "", "", "" }, { "1", "deagle", "0", "0", "0" }, { "2", "elite", "0", "0", "0" }, { "3", "fiveseven", "0", "0", "0" }, { "4", "glock", "0", "0", "0" }, { "7", "ak47", "0", "0", "0" }, { "8", "aug", "0", "0", "0" }, { "9", "awp", "0", "0", "0" }, { "10", "famas", "0", "0", "0" }, { "11", "g3sg1", "0", "0", "0" }, { "13", "galilar", "0", "0", "0" }, { "14", "m249", "0", "0", "0" }, { "16", "m4a1", "0", "0", "0" }, { "17", "mac10", "0", "0", "0" }, { "19", "p90", "0", "0", "0" }, { "24", "ump45", "0", "0", "0" }, { "25", "xm1014", "0", "0", "0" }, { "26", "bizon", "0", "0", "0" }, { "27", "mag7", "0", "0", "0" }, { "28", "negev", "0", "0", "0" }, { "29", "sawedoff", "0", "0", "0" }, { "30", "tec9", "0", "0", "0" }, { "31", "taser", "0", "0", "" }, { "32", "hkp2000", "0", "0", "0" }, { "33", "mp7", "0", "0", "0" }, { "34", "mp9", "0", "0", "0" }, { "35", "nova", "0", "0", "0" }, { "36", "p250", "0", "0", "0" }, { "38", "scar20", "0", "0", "0" }, { "39", "sg556", "0", "0", "0" }, { "40", "ssg08", "0", "0", "0" }, { "42", "knife", "0", "0", "0" }, { "44", "hegrenade", "0", "0", "0" } };
                        responcearr = responce.Split(',');
                        for (int i = 2; i < responcearr.Length; i = i + 2)
                        {
                            string currentline = new string(responcearr[i].Where(c => char.IsLetterOrDigit(c) || char.IsWhiteSpace(c) || c == '-').ToArray());
                            string currentvalue = new string(responcearr[i + 1].Where(c => char.IsLetterOrDigit(c) || char.IsWhiteSpace(c) || c == '-').ToArray());
                            currentline = currentline.Substring(4);
                            currentvalue = currentvalue.Substring(5);
                            for (int b = 1; b < 33; b++)
                            {
                                if (currentline == $"totalkills" + weapons[b, 1])
                                {
                                    weapons[b, 2] = currentvalue;
                                }
                                else if (currentline == $"totalshots" + weapons[b, 1])
                                {
                                    weapons[b, 3] = currentvalue;
                                }
                                else if (currentline == $"totalhits" + weapons[b, 1])
                                {
                                    weapons[b, 4] = currentvalue;
                                }
                            }
                        }
                        WeaponsForUser.Add(weapons);
                    }
                    else
                    {
                        errorlist += $"The SteamID:{steamID.ToString()} Failed To Retreave Data From The API, ";
                    }
                }
            }
            /*
             * 
             * 
             * Add Upload To DB Useing Weapons For User
             * List Of 2D Arrays
             * First Item In Each 2D Array Is {ID,"","","",""}
             * Rest Are {WeaponID,WeaponName,Kills,Shots,Hits}
             * 
             * 
             * 
             */
            return errorlist;
        }
    }
}
